$(document).ready(function () {
    $('img').click(function () {
        var storage = $(this).attr('data-alt-src');
        $(this).attr('src', storage);
    });
    
    
//    $('').ready(function){
//        $(this).attr('');    
//    });
    
    
    
    
    
    
    
});